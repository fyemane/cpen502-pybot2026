"""
Auto-generated __init__.py for schema types.
"""

from typing import Any, Type

from .server_handshake import ServerHandshake
from .bot_intent import BotIntent
from .bot_state_with_id import BotStateWithId
from .bot_death_event import BotDeathEvent
from .observer_handshake import ObserverHandshake
from .bot_list_update import BotListUpdate
from .change_tps import ChangeTps
from .bot_state import BotState
from .game_ended_event_for_bot import GameEndedEventForBot
from .skipped_turn_event import SkippedTurnEvent
from .bot_address import BotAddress
from .round_started_event import RoundStartedEvent
from .bot_handshake import BotHandshake
from .tps_changed_event import TpsChangedEvent
from .game_setup import GameSetup
from .tick_event_for_bot import TickEventForBot
from .game_paused_event_for_observer import GamePausedEventForObserver
from .results_for_bot import ResultsForBot
from .game_aborted_event import GameAbortedEvent
from .game_resumed_event_for_observer import GameResumedEventForObserver
from .tick_event_for_observer import TickEventForObserver
from .disable_debug_mode import DisableDebugMode
from .next_turn import NextTurn
from .bullet_state import BulletState
from .team_message import TeamMessage
from .bullet_hit_wall_event import BulletHitWallEvent
from .bot_info import BotInfo
from .bot_name import BotName
from .round_ended_event_for_bot import RoundEndedEventForBot
from .bullet_hit_bot_event import BulletHitBotEvent
from .hit_by_bullet_event import HitByBulletEvent
from .initial_position import InitialPosition
from .bot_ready import BotReady
from .results_for_observer import ResultsForObserver
from .controller_handshake import ControllerHandshake
from .round_ended_event_for_observer import RoundEndedEventForObserver
from .bot_hit_bot_event import BotHitBotEvent
from .color import Color
from .bot_hit_wall_event import BotHitWallEvent
from .won_round_event import WonRoundEvent
from .game_ended_event_for_observer import GameEndedEventForObserver
from .bullet_fired_event import BulletFiredEvent
from .scanned_bot_event import ScannedBotEvent
from .start_game import StartGame
from .enable_debug_mode import EnableDebugMode
from .team_message_event import TeamMessageEvent
from .message import Message
from .participant import Participant
from .event import Event
from .game_started_event_for_bot import GameStartedEventForBot
from .bullet_hit_bullet_event import BulletHitBulletEvent
from .bot_policy_update import BotPolicyUpdate
from .resume_game import ResumeGame
from .pause_game import PauseGame
from .game_started_event_for_observer import GameStartedEventForObserver
from .stop_game import StopGame

__all__ = [
    "ServerHandshake",
    "BotIntent",
    "BotStateWithId",
    "BotDeathEvent",
    "ObserverHandshake",
    "BotListUpdate",
    "ChangeTps",
    "BotState",
    "GameEndedEventForBot",
    "SkippedTurnEvent",
    "BotAddress",
    "RoundStartedEvent",
    "BotHandshake",
    "TpsChangedEvent",
    "GameSetup",
    "TickEventForBot",
    "GamePausedEventForObserver",
    "ResultsForBot",
    "GameAbortedEvent",
    "GameResumedEventForObserver",
    "TickEventForObserver",
    "DisableDebugMode",
    "NextTurn",
    "BulletState",
    "TeamMessage",
    "BulletHitWallEvent",
    "BotInfo",
    "BotName",
    "RoundEndedEventForBot",
    "BulletHitBotEvent",
    "HitByBulletEvent",
    "InitialPosition",
    "BotReady",
    "ResultsForObserver",
    "ControllerHandshake",
    "RoundEndedEventForObserver",
    "BotHitBotEvent",
    "Color",
    "BotHitWallEvent",
    "WonRoundEvent",
    "GameEndedEventForObserver",
    "BulletFiredEvent",
    "ScannedBotEvent",
    "StartGame",
    "EnableDebugMode",
    "TeamMessageEvent",
    "Message",
    "Participant",
    "Event",
    "GameStartedEventForBot",
    "BulletHitBulletEvent",
    "BotPolicyUpdate",
    "ResumeGame",
    "PauseGame",
    "GameStartedEventForObserver",
    "StopGame"
]

CLASS_MAP: dict[str, Type[Any]] = {
    "ServerHandshake": ServerHandshake,
    "BotIntent": BotIntent,
    "BotStateWithId": BotStateWithId,
    "BotDeathEvent": BotDeathEvent,
    "ObserverHandshake": ObserverHandshake,
    "BotListUpdate": BotListUpdate,
    "ChangeTps": ChangeTps,
    "BotState": BotState,
    "GameEndedEventForBot": GameEndedEventForBot,
    "SkippedTurnEvent": SkippedTurnEvent,
    "BotAddress": BotAddress,
    "RoundStartedEvent": RoundStartedEvent,
    "BotHandshake": BotHandshake,
    "TpsChangedEvent": TpsChangedEvent,
    "GameSetup": GameSetup,
    "TickEventForBot": TickEventForBot,
    "GamePausedEventForObserver": GamePausedEventForObserver,
    "ResultsForBot": ResultsForBot,
    "GameAbortedEvent": GameAbortedEvent,
    "GameResumedEventForObserver": GameResumedEventForObserver,
    "TickEventForObserver": TickEventForObserver,
    "DisableDebugMode": DisableDebugMode,
    "NextTurn": NextTurn,
    "BulletState": BulletState,
    "TeamMessage": TeamMessage,
    "BulletHitWallEvent": BulletHitWallEvent,
    "BotInfo": BotInfo,
    "BotName": BotName,
    "RoundEndedEventForBot": RoundEndedEventForBot,
    "BulletHitBotEvent": BulletHitBotEvent,
    "HitByBulletEvent": HitByBulletEvent,
    "InitialPosition": InitialPosition,
    "BotReady": BotReady,
    "ResultsForObserver": ResultsForObserver,
    "ControllerHandshake": ControllerHandshake,
    "RoundEndedEventForObserver": RoundEndedEventForObserver,
    "BotHitBotEvent": BotHitBotEvent,
    "Color": Color,
    "BotHitWallEvent": BotHitWallEvent,
    "WonRoundEvent": WonRoundEvent,
    "GameEndedEventForObserver": GameEndedEventForObserver,
    "BulletFiredEvent": BulletFiredEvent,
    "ScannedBotEvent": ScannedBotEvent,
    "StartGame": StartGame,
    "EnableDebugMode": EnableDebugMode,
    "TeamMessageEvent": TeamMessageEvent,
    "Message": Message,
    "Participant": Participant,
    "Event": Event,
    "GameStartedEventForBot": GameStartedEventForBot,
    "BulletHitBulletEvent": BulletHitBulletEvent,
    "BotPolicyUpdate": BotPolicyUpdate,
    "ResumeGame": ResumeGame,
    "PauseGame": PauseGame,
    "GameStartedEventForObserver": GameStartedEventForObserver,
    "StopGame": StopGame,
}
