"""
Generated Python class from bot-name.schema.yaml
This file is auto-generated. Do not edit manually.
"""


class BotName:
    """A bot id and its server-assigned battle name."""

    def __init__(self, bot_id: int | None, name: str | None):
        if name is None:
            raise ValueError("The 'name' parameter must be provided.")
        if bot_id is None:
            raise ValueError("The 'bot_id' parameter must be provided.")
        self.bot_id = bot_id
        self.name = name
